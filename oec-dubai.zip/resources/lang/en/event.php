<?php

return [
    'menu' => 'Events',
    'add_event' => "Add Events",
    'edit_event' => "Edit Events",
    'name' => 'Event Name',
    'place' => 'Event Place',
    'date' => 'Event Date',
    'time' => 'Event Time',
    'description' => 'Event Description',
    'image' => 'Event Image',
    'category' => 'Event Category',
    'submit' => "Store Event",
    'action' => "Action",
];
