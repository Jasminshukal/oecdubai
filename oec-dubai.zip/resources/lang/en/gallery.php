<?php
return [
    'menu' => 'Gallery',
    'add_gallery' => "Add Gallery",
    'edit_gallery' => "Edit Gallery",
    'title' => 'Gallery Title',
    'date' => 'Gallery Date',
    'description' => 'Gallery Short Description',
    'image' => 'Gallery Image',
    'category' => 'Gallery Category',
    'submit' => "Store Gallery",
    'action' => "Action",
    'success' => "Successfully Add Gallery",
    'delete' => "Successfully Delete Gallery"
];

