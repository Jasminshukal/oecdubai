<?php
return [
    'menu' => 'Blogs',
    'add_blog' => "Add Blogs",
    'edit_blog' => "Edit Blogs",
    'like' => "Likes",
    'name' => 'Blog Title',
    'description' => 'Blog Description',
    'image' => 'Blog Image',
    'category' => 'Blog Category',
    'submit' => "Store Blog",
    'action' => "Action",
    'comments' => "Comments",
    'success' => "Successfully Blog Added",
    'delete' => "Successfully Blog Added",
];
